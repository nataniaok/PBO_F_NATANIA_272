public class HEWAN  {
    // membuat 3 artibut dengan tipe data string
    String Nama;
    String Jenis;
    String Suara;

    // membuat methode yang mencetak informasi hewan seperti nama, jenis dan suara
    void tampilkanInfo() {
        System.out.println("\nNama : " + Nama);
        System.out.println("Jenis : " + Jenis);
        System.out.println("Suara : " + Suara);
    };

}
